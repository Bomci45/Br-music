BR MUSIC — MAQUETTE WEB INSTALLABLE
===================================

Fichiers :
- index.html : maquette interactive (accueil, chansons, artistes, clips, recherche, filtres et langues FR/LN/EN)
- manifest.json : paramètres de l'application web installable
- sw.js : cache hors ligne de base

DÉMARRAGE RAPIDE
1. Décompressez br_music_maquette.zip.
2. Ouvrez index.html dans un navigateur pour tester l'interface.
   La navigation et les boutons de démonstration fonctionnent localement.
3. Pour tester l'installation PWA et le mode hors ligne, hébergez le dossier
   sur un service HTTPS (par exemple GitHub Pages) ; les service workers ne
   fonctionnent généralement pas depuis un fichier local file://.
4. Sur Android, ouvrez l'adresse HTTPS dans Chrome puis choisissez
   « Installer l'application » ou « Ajouter à l'écran d'accueil » selon le navigateur.

IMPORTANT
- Cette maquette ne contient pas de vrais fichiers audio/vidéo et n'est pas encore
  reliée à une base de données ni à des comptes utilisateurs.
- Les artistes et titres affichés sont fictifs.
- Avant de publier de la musique, obtenez les autorisations nécessaires.
- Pour la production, ajouter des icônes 192x192 et 512x512 au manifest, un vrai
  formulaire de soumission, une base de données sécurisée, une politique de
  confidentialité et un système de modération.
- Les boutons de lecture sont simulés ; la lecture réelle sera ajoutée dans une
  étape ultérieure avec des sources audio/vidéo autorisées.
